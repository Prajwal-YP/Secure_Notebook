package com.example.project;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText sname,lname,spass,lpass;
    Button sbtn,lbtn;
    Switch swtch;
    DBConnection db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sname=findViewById(R.id.edtSignName);
        spass=findViewById(R.id.edtSignPass);
        lname=findViewById(R.id.edtLogName);
        lpass=findViewById(R.id.edtLogPass);
        sbtn=findViewById(R.id.btnSign);
        lbtn=findViewById(R.id.btnLog);
        swtch = findViewById(R.id.switch1);
        db = new DBConnection(this);

    }

    public void sign(View view) {
        String name= sname.getText().toString();
        String pass=spass.getText().toString();

        boolean result = db.insertNew(name,pass,"");
        if(result==true){
            Toast.makeText(this, "Successfully Signed Up", Toast.LENGTH_SHORT).show();
            sname.setText("");
            spass.setText("");
        }
        else
            Toast.makeText(this, "User Email Already Registered!!", Toast.LENGTH_SHORT).show();
    }

    public void log(View view) {
        String name= lname.getText().toString();
        String pass=lpass.getText().toString();
        String upass="";



       try {
           Cursor cursor = db.verifyData(name);
           cursor.moveToFirst();

           do{
               upass = upass + String.valueOf(cursor.getString(cursor.getColumnIndex("PASSWORD")));
           }while (cursor.moveToNext());

       }catch (Exception e){
           Toast.makeText(this, "Email Not Exists !!", Toast.LENGTH_SHORT).show();
           return;
       }

       if(upass.equals(pass)){
           Toast.makeText(this, "Login Successfull", Toast.LENGTH_SHORT).show();
           Intent move = new Intent(MainActivity.this,MainActivity2.class);
           move.putExtra("email",name);
           startActivity(move);
       }
       else {
           Toast.makeText(this, "Invalid Password", Toast.LENGTH_SHORT).show();
       }
    }

    public void swtch(View view) {
        if (swtch.isChecked()){
            lname.setVisibility(View.VISIBLE);
            lpass.setVisibility(View.VISIBLE);
            lbtn.setVisibility(View.VISIBLE);
            sname.setVisibility(View.INVISIBLE);
            spass.setVisibility(View.INVISIBLE);
            sbtn.setVisibility(View.INVISIBLE);
            sname.setText("");
            spass.setText("");
        }
        else{
            sname.setVisibility(View.VISIBLE);
            spass.setVisibility(View.VISIBLE);
            sbtn.setVisibility(View.VISIBLE);
            lname.setVisibility(View.INVISIBLE);
            lpass.setVisibility(View.INVISIBLE);
            lbtn.setVisibility(View.INVISIBLE);
            lname.setText("");
            lpass.setText("");
        }
    }
}