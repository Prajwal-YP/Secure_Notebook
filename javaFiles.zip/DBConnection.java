package com.example.project;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBConnection extends SQLiteOpenHelper {
    public DBConnection(Context context) {
        super(context, "UserDB", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE USERS(EMAIL TEXT PRIMARY KEY,PASSWORD TEXT,STRING TEXT);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
    }

    public  boolean insertNew(String email,String password,String string){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("EMAIL",email);
        contentValues.put("PASSWORD",password);
        contentValues.put("STRING",string);
        long result=db.insert("USERS",null,contentValues);

        if(result==-1)
            return  false;
        else
            return true;
    }

    public Cursor verifyData(String email){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM USERS WHERE EMAIL = '"+email+"'",null);
        return  cursor;
    }

    public boolean insertString(String email,String string){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("STRING",string);

        long result = db.update("USERS",contentValues,"EMAIL = ?",new String[]{email});

        if(result==-1)
            return  false;
        else
            return true;
    }

    public  Cursor copystring(String email){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM USERS WHERE EMAIL = '"+email+"'",null);
        return  cursor;
    }

}
