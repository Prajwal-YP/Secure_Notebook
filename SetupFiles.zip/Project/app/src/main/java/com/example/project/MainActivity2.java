package com.example.project;

import android.database.Cursor;
import android.graphics.Typeface;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.style.StyleSpan;
import android.text.style.UnderlineSpan;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;

public class MainActivity2 extends AppCompatActivity {

    EditText edt;
    String initial="";
    TextToSpeech tts;
    DBConnection db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        edt=findViewById(R.id.edtTxt);
        tts = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int i) {
                if(i==tts.SUCCESS){
                    tts.setLanguage(Locale.JAPANESE);
                }
            }
        });
        String email = getIntent().getStringExtra("email");
        db = new DBConnection(this);


        try {
            Cursor cursor = db.copystring(email);
            cursor.moveToFirst();

            do{
                initial = initial + String.valueOf(cursor.getString(cursor.getColumnIndex("STRING")));
            }while (cursor.moveToNext());
        }catch (Exception e){
        }

        edt.setText(initial);
    }

    public void bold(View view) {
        Spannable spannable =new SpannableStringBuilder(edt.getText());
        spannable.setSpan(new StyleSpan(Typeface.BOLD),
                    edt.getSelectionStart(),
                    edt.getSelectionEnd(),
                    0);
        edt.setText(spannable);
        return;
    }

    public void underline(View view) {
        Spannable spannable =new SpannableStringBuilder(edt.getText());
        spannable.setSpan(new UnderlineSpan(),
                edt.getSelectionStart(),
                edt.getSelectionEnd(),
                0);
        edt.setText(spannable);
        return;
    }

    public void italic(View view) {
        Spannable spannable =new SpannableStringBuilder(edt.getText());
        spannable.setSpan(new StyleSpan(Typeface.ITALIC),
                edt.getSelectionStart(),
                edt.getSelectionEnd(),
                0);
        edt.setText(spannable);
        return;
    }

    public void talk(View view) {
        String txt=edt.getText().toString();
        tts.speak(txt,TextToSpeech.QUEUE_FLUSH,null);

    }

    public void noformat(View view) {
        edt.setText(edt.getText().toString());
        return;
    }

    public void save(View view) {
        String email = getIntent().getStringExtra("email");
        String string = edt.getText().toString();
        boolean result = db.insertString(email,string);
        if(result==true){
            Toast.makeText(this, "Successfully Saved", Toast.LENGTH_SHORT).show();
        }
        else
            Toast.makeText(this, "Not Saved", Toast.LENGTH_SHORT).show();
    }

    public void download(View view) {
    }

    public void reset(View view) {
        edt.setText("");
    }
}